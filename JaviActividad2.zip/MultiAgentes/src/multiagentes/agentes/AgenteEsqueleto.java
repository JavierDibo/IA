package multiagentes.agentes;

import jade.core.Agent;

public class AgenteEsqueleto extends Agent {

    @Override
    protected void setup() {
        //Inicializar variables del agente

        //Configuracion del GUI
        //Registro del agente en las paginas amarillas
        //Registro de ontrologia
        System.out.println("Hola compañeros de IA, soy " + this.getLocalName()
                + ". Acabo de iniciar mi ejecución y estoy en\n' " + this + "' y este es mi estado: " + this.getAgentState());

        //Añadir tareas principales
    }

    @Override
    protected void takeDown() {

        //Desregistro del agente de las paginas amillas
        //Liberacion de recursos, incluido el GUI
        //Despedida        
        System.out.println("Finaliza la ejecucion del agente: " + this.getLocalName());
    }

    //Metodos de trbaajo del agente
    //Clases internas que representan las tareas del agente
}

package actividad1ia;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class Actividad1IA {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try (DataOutputStream ds = new DataOutputStream(
                new BufferedOutputStream(
                        new FileOutputStream("datos")))) {
            ds.writeInt(5);
            ds.writeFloat((float) 4.5);
            ds.writeChars(
                    "Hola");
        }
        DataInputStream dc;
        dc = new DataInputStream(
                new BufferedInputStream(
                        new FileInputStream(
                                "datos")));
        int k = dc.readInt();
        System.out.println(k);
        dc.close();

        Alumno alumno;
        alumno = new Alumno("Javier", "Dibo", "77646884B", "jfdg0002");

        //alumno.mostrarAlumno(alumno);
        Alumno_IA alumnoIA;
        float[] lista = {1, 2, 3, 4};
        alumnoIA = new Alumno_IA("a", "b", "c", "D", 'E', 'F', lista);

        //alumnoIA.mostrarAlumno(alumnoIA);
        //alumnoIA.mediaNotasPracticas();
    }
}

package actividad1ia;

import java.util.Arrays;
import java.util.Scanner;

public class Alumno_IA extends Alumno {

    private char grupoTeoria;
    private char grupoPracticas;
    private float[] notaPracticas;

    public static final int NUMERO_PRACTICAS = 4;

    public Alumno_IA() {
    }

    public Alumno_IA(String nombre, String apellido, String DNI, String correo, char grupoTeoria, char grupoPracticas, float[] notaPracticas) {
        super(nombre, apellido, DNI, correo);
        this.grupoTeoria = grupoTeoria;
        this.grupoPracticas = grupoPracticas;
        this.notaPracticas = notaPracticas;
    }

    public void mediaNotasPracticas() {
        float media;
        media = 0;
        Scanner leer = new Scanner(System.in);

        for (int i = 0; i < NUMERO_PRACTICAS; i++) {
            System.out.println("Introduzca la nota de la practica " + i + ": ");
            this.notaPracticas[i] = leer.nextFloat();
            media += this.notaPracticas[i];
        }
        media /= NUMERO_PRACTICAS;
        System.out.println("La media de nota de prácticas es: " + media);
    }

    @Override
    public String toString() {
        return "Alumno_IA{nombre=" + nombre + ", apellido=" + apellido + ", DNI=" + DNI + ", correo=" + correo + ", grupoTeoria=" + grupoTeoria + ", grupoPracticas=" + grupoPracticas + ", notaPracticas=" + Arrays.toString(notaPracticas) + '}';
    }

    public void mostrarAlumno(Alumno_IA alumno) {
        System.out.println(alumno.toString());
    }
}

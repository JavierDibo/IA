package actividad1ia;

import java.util.Scanner;

public class Alumno {

    protected String nombre;
    protected String apellido;
    protected String DNI;
    protected String correo;

    /**
     * @brief constructor por defecto
     */
    public Alumno() {

    }

    /**
     * @brief constructor parametrizado
     * @param nombre
     * @param apellido
     * @param DNI
     * @param correo
     */
    public Alumno(String nombre, String apellido, String DNI, String correo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
        this.correo = correo;
    }

    /**
     * @brief Crea un nuevo alumno a partir de los datos obtenidos por consola
     * @return nuevo Alumno creado
     */
    public Alumno nuevoAlumno() {
        String nuevoNombre, nuevoApellido, nuevoDNI, nuevoCorreo;
        Alumno nuevoAlumno;
        Scanner leer = new Scanner(System.in);
        System.out.println("Introduzca el nombre: ");
        nuevoNombre = leer.nextLine();
        System.out.println("Introduzca el apellido: ");
        nuevoApellido = leer.nextLine();
        System.out.println("Introduzca el DNI: ");
        nuevoDNI = leer.nextLine();
        System.out.println("Introduzca el correo: ");
        nuevoCorreo = leer.nextLine();
        nuevoAlumno = new Alumno(nuevoNombre, nuevoApellido, nuevoDNI, nuevoCorreo);
        return nuevoAlumno;
    }

    /**
     *
     * @param alumno objeto a leer
     * @brief Devuelve los datos de un alumno por consola
     */
    public void mostrarAlumno(Alumno alumno) {
        System.out.println(alumno.toString());
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", apellido=" + apellido + ", DNI=" + DNI + ", correo=" + correo + '}';
    }
}
